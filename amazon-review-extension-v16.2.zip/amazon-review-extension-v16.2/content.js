/* bh life Amazonレビュー全件収集ツール - content.js v16.2
 * 拡張機能版: ページ遷移後も毎回自動実行されるので全自動で完走できる
 * 状態は chrome.storage.local で保持
 * v16.2: pushState遷移バグ修正・ページネーション検出強化
 */
(function () {
  'use strict';

  var url = location.href, asin = null, m;
  m = url.match(/\/product-reviews\/([A-Z0-9]{10})/i); if (m) asin = m[1].toUpperCase();
  if (!asin) return; // レビューページでなければ何もしない

  var FILTERS = [
    {key:'',           label:'全体'},
    {key:'five_star',  label:'★5'},
    {key:'four_star',  label:'★4'},
    {key:'three_star', label:'★3'},
    {key:'two_star',   label:'★2'},
    {key:'one_star',   label:'★1'}
  ];

  var START_KEY = 'start_' + asin;
  var STATE_KEY = 'state_' + asin;

  function getLocal(keys){ return new Promise(function(res){ chrome.storage.local.get(keys, res); }); }
  function setLocal(obj){ return new Promise(function(res){ chrome.storage.local.set(obj, res); }); }
  function removeLocal(keys){ return new Promise(function(res){ chrome.storage.local.remove(keys, res); }); }

  function buildUrl(filterKey, pageNum, token){
    var u = 'https://www.amazon.co.jp/product-reviews/' + asin + '/?sortBy=recent&pageNumber=' + (pageNum||1);
    if(filterKey) u += '&filterByStar=' + filterKey;
    if(token) u += '&nextPageToken=' + encodeURIComponent(token);
    return u;
  }

  function parseRating(el) {
    var s = el.querySelector('i[data-hook="review-star-rating"]') || el.querySelector('i[class*="a-star-"]');
    if (s) { var c = (s.className||'').match(/\ba-star-(\d+)\b/); if (c) return parseInt(c[1]); }
    var span = el.querySelector('span[data-hook="review-star-rating"]');
    if (span) { var c2 = (span.className||'').match(/\ba-star-(\d+)\b/); if (c2) return parseInt(c2[1]); }
    return 0;
  }
  function parseTitle(el) {
    if (!el) return '';
    var c = el.cloneNode(true);
    c.querySelectorAll('.a-icon-alt,i.a-icon').forEach(function(n){ n.parentNode&&n.parentNode.removeChild(n); });
    return c.textContent.replace(/\s+/g,' ').trim();
  }
  function isVine(el){
    if(el.querySelector('[data-hook="avp-badge"]')) return false;
    var txt = el.textContent || '';
    if(txt.indexOf('Amazonで購入') >= 0) return false;
    if(txt.indexOf('Verified Purchase') >= 0) return false;
    if(el.querySelector('[data-hook="vine-customer-review-tag"]')) return true;
    var bEl = el.querySelector('[data-hook="review-body"] span') || el.querySelector('[data-hook="review-body"]');
    if(bEl && bEl.textContent.trim().length < 5) return false;
    return true;
  }
  var MO={January:'01',February:'02',March:'03',April:'04',May:'05',June:'06',July:'07',August:'08',September:'09',October:'10',November:'11',December:'12'};
  function cleanDate(raw){
    var j=raw.match(/(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日/);if(j)return j[1]+'/'+('0'+j[2]).slice(-2)+'/'+('0'+j[3]).slice(-2);
    var e=raw.match(/(\w+)\s+(\d+),\s+(\d{4})/);if(e&&MO[e[1]])return e[3]+'/'+MO[e[1]]+'/'+('0'+e[2]).slice(-2);
    return raw.replace(/に日本でレビュー済み.*/,'').replace(/Reviewed in.*on\s*/,'').trim();
  }
  function toYM(d){var m2=d.match(/^(\d{4})\/(\d{2})/);return m2?m2[1]+'/'+m2[2]:null;}
  function normBody(b){ return (b||'').replace(/\s+/g,'').slice(0,80); }
  function delay(ms){ return new Promise(function(r){setTimeout(r,ms);}); }

  function collectCurrentPage(st){
    var added = 0;
    document.querySelectorAll('[data-hook="review"]').forEach(function(el){
      var rating = parseRating(el);
      var titleEl = el.querySelector('[data-hook="review-title"]') || el.querySelector('[class*="review-title"]');
      var title = parseTitle(titleEl);
      var bEl = el.querySelector('[data-hook="review-body"] span') || el.querySelector('[data-hook="review-body"]') || el.querySelector('[class*="review-text"]');
      var body = bEl ? bEl.textContent.trim() : '';
      var dEl = el.querySelector('[data-hook="review-date"]') || el.querySelector('[class*="review-date"]');
      var date = cleanDate(dEl ? dEl.textContent.trim() : '');
      var vine = isVine(el), rid = el.id || '';
      var key = rid && rid.length>3 ? 'id:'+rid : 'bd:'+normBody(body)+'|'+date;
      if(st.seenKeys[key]) return;
      st.seenKeys[key] = true;
      if(body||title){ st.reviews.push({rating:rating,title:title,body:body,date:date,vine:vine,rid:rid}); added++; }
    });
    return added;
  }
  function findShowMore(){
    var bar = document.getElementById('cm_cr-pagination_bar');
    if(!bar) return null;
    var t = (bar.textContent||'').trim();

    // パターン1: 「さらにN件のレビューを表示」ボタン（AJAX/インフィニットスクロール）
    if(t.indexOf('さらに')>=0 && t.indexOf('レビュー')>=0 && t.indexOf('表示')>=0){
      return bar.querySelector('a.a-button-text') || bar.querySelector('.a-button-input') || bar.querySelector('a');
    }
    // パターン2: 標準ページネーション「次のページ」リンク
    var nextLi = bar.querySelector('li.a-last:not(.a-disabled)') || bar.querySelector('.a-pagination li.a-last:not(.a-disabled)');
    if(nextLi){
      var a = nextLi.querySelector('a');
      if(a) return a;
    }
    // パターン3: href に pageNumber が含まれる「次へ」リンク（フォールバック）
    var allLinks = bar.querySelectorAll('a[href*="pageNumber"]');
    for(var i=0;i<allLinks.length;i++){
      var txt = (allLinks[i].textContent||'').trim();
      if(txt === '次へ' || txt === '次のページ' || txt === '>') return allLinks[i];
    }
    return null;
  }

  function updateProgress(msg){
    var bar = document.getElementById('_bhl_prog');
    if(!bar){
      bar = document.createElement('div'); bar.id = '_bhl_prog';
      bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#0F172A;color:#fff;padding:12px 20px;font-family:sans-serif;display:flex;align-items:center;gap:12px;box-shadow:0 2px 12px rgba(0,0,0,.7)';
      document.body.appendChild(bar);
    }
    bar.innerHTML = '<span style="font-size:22px;flex-shrink:0">⏳</span>'
      + '<div style="flex:1"><div style="font-weight:700;color:#FF9900;font-size:14px">Amazonレビュー全件収集中（拡張機能版）</div>'
      + '<div style="font-size:12px;color:#94A3B8;margin-top:2px">' + msg + '</div></div>'
      + '<button id="_bhl_stop" style="background:#FF4B4B;border:none;color:#fff;padding:6px 12px;border-radius:6px;font-size:11px;cursor:pointer;flex-shrink:0">中止</button>';
    var stopBtn = document.getElementById('_bhl_stop');
    if(stopBtn) stopBtn.onclick = function(){
      removeLocal([STATE_KEY, START_KEY]).then(function(){
        location.href = 'https://www.amazon.co.jp/product-reviews/'+asin+'/?sortBy=recent';
      });
    };
  }
  function removeProgress(){ var b=document.getElementById('_bhl_prog'); if(b) b.remove(); }

  async function runStep(){
    var data = await getLocal([STATE_KEY]);
    var st = data[STATE_KEY];
    if(!st){
      st = { reviews:[], seenKeys:{}, filterIdx:0, clicksInFilter:0 };
    }
    var curFilter = FILTERS[st.filterIdx];
    var added = collectCurrentPage(st);
    await setLocal({[STATE_KEY]: st});
    updateProgress('[' + curFilter.label + '] 収集中… 累計 ' + st.reviews.length + ' 件（+' + added + '）');

    await delay(700);
    var btn = findShowMore();

    if(btn && st.clicksInFilter < 10){
      st.clicksInFilter++;
      await setLocal({[STATE_KEY]: st});
      updateProgress('[' + curFilter.label + '] ' + st.reviews.length + '件 → 次の10件を読込中…');
      try { btn.scrollIntoView({block:'center'}); } catch(e){}
      btn.click();
      // pushState遷移（URLは変わるがリロードなし）でもfull遷移でも対応:
      // full遷移ならこのページのDOMは破棄されるのでsetTimeoutは発火しない
      // pushState遷移ならDOMが残るのでsetTimeoutでrunStepを再呼び出し
      setTimeout(function(){ runStep(); }, 3500);
      return;
    }

    // フィルター終了 → 次へ
    st.filterIdx++;
    st.clicksInFilter = 0;
    await setLocal({[STATE_KEY]: st});

    if(st.filterIdx >= FILTERS.length){
      await finish(st);
      return;
    }
    var nextFilter = FILTERS[st.filterIdx];
    updateProgress('[' + curFilter.label + ']完了 → [' + nextFilter.label + ']へ切替… 累計' + st.reviews.length + '件');
    location.href = buildUrl(nextFilter.key, 1, null);
  }

  async function finish(st){
    await removeLocal([STATE_KEY, START_KEY]);
    removeProgress();
    showPanel(st.reviews);
    playDone();
    window.scrollTo(0,0);
  }

  function avg(list){var v=list.filter(function(r){return r.rating>0;});return v.length?(v.reduce(function(s,r){return s+r.rating;},0)/v.length).toFixed(2):null;}
  function distChart(reviews,label,color){
    var dist={1:0,2:0,3:0,4:0,5:0};
    reviews.forEach(function(r){var s=Math.round(r.rating);if(dist[s]!==undefined)dist[s]++;});
    var total=reviews.length,maxD=Math.max.apply(null,[1,2,3,4,5].map(function(s){return dist[s];})||1)||1,a=avg(reviews);
    var bars=[5,4,3,2,1].map(function(s){
      var cnt=dist[s],pct=total>0?Math.round(cnt/total*100):0,w=Math.round(cnt/maxD*100),bc=s>=4?'#22C55E':(s===3?'#94A3B8':'#FF4B4B');
      return '<div style="display:flex;align-items:center;gap:5px;margin-bottom:3px"><span style="color:#FF9900;font-size:11px;width:12px;text-align:right">'+s+'</span><span style="color:#FF9900;font-size:10px">★</span><div style="flex:1;height:9px;background:#1E3A5F;border-radius:3px;overflow:hidden"><div style="height:100%;width:'+w+'%;background:'+bc+';border-radius:3px"></div></div><span style="font-size:10px;color:#E2E8F0;width:22px;text-align:right">'+cnt+'</span><span style="font-size:10px;color:#64748B;width:38px">('+pct+'%)</span></div>';
    }).join('');
    return '<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:5px"><span style="font-size:11px;font-weight:700;color:'+color+'">'+label+'</span><span style="font-size:14px;font-weight:700;color:'+color+'">'+(a||'?')+'★　<span style="font-size:11px;color:#64748B;font-weight:400">'+total+'件</span></span></div>'+bars+'</div>';
  }
  function monthChart(reviews){
    var counts={};
    reviews.forEach(function(r){var ym=toYM(r.date);if(ym)counts[ym]=(counts[ym]||0)+1;});
    var months=Object.keys(counts).sort().reverse();
    if(!months.length)return '';
    var total=reviews.length,maxC=Math.max.apply(null,months.map(function(k){return counts[k];}));
    var bars=months.slice(0,36).map(function(ym){
      var cnt=counts[ym],pct=Math.round(cnt/total*100),w=Math.round(cnt/maxC*100);
      return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px"><span style="font-size:11px;color:#94A3B8;width:52px;flex-shrink:0">'+ym+'</span><div style="flex:1;height:12px;background:#1E3A5F;border-radius:3px;overflow:hidden"><div style="height:100%;width:'+w+'%;background:#22C55E;border-radius:3px"></div></div><span style="font-size:11px;color:#E2E8F0;width:36px;text-align:right;flex-shrink:0">'+cnt+'件</span><span style="font-size:11px;color:#64748B;width:32px;flex-shrink:0">'+pct+'%</span></div>';
    }).join('');
    return '<div style="padding:12px 16px;background:#162032;border-bottom:1px solid #1E3A5F"><div style="font-size:11px;font-weight:700;color:#94A3B8;margin-bottom:8px">📅 月別レビュー数</div>'+bars+'</div>';
  }

  function showPanel(reviews){
    reviews = reviews.slice().sort(function(a,b){return b.date.localeCompare(a.date);});
    var total=reviews.length;
    var vRv=reviews.filter(function(r){return r.vine;}),nvRv=reviews.filter(function(r){return !r.vine;});
    var vC=vRv.length,nvC=nvRv.length,vP=total>0?Math.round(vC/total*100):0;
    var goodC=reviews.filter(function(r){return Math.round(r.rating)>=4;}).length;
    var midC=reviews.filter(function(r){return Math.round(r.rating)===3;}).length;
    var badC=reviews.filter(function(r){var s=Math.round(r.rating);return s<=2&&s>0;}).length;
    var aAll=avg(reviews)||'?';
    var listHTML=reviews.slice(0,500).map(function(r,i){
      var rnd=Math.round(r.rating),stars='★'.repeat(rnd)+'☆'.repeat(5-rnd);
      var vb=r.vine?'<span style="background:#3B1E6E;color:#C4B5FD;padding:2px 6px;border-radius:10px;font-size:10px;margin-right:3px">Vine</span>':'<span style="background:#0E4B5F;color:#67E8F9;padding:2px 6px;border-radius:10px;font-size:10px;margin-right:3px">Amazonで購入</span>';
      var lbl=rnd<=2&&rnd>0?'<span style="background:#FF4B4B22;color:#FF4B4B;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px">悪い</span>':rnd>=4?'<span style="background:#22C55E22;color:#22C55E;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px">良い</span>':rnd===3?'<span style="background:#94A3B822;color:#94A3B8;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px">普通</span>':'';
      var bc=rnd<=2&&rnd>0?'#FF4B4B':(rnd>=4?'#22C55E':'#94A3B8');
      return '<div data-idx="'+i+'" data-r="'+r.rating+'" data-vine="'+(r.vine?'1':'0')+'" style="border-left:3px solid '+bc+';padding:10px 10px 10px 12px;margin-top:8px;background:#162032;border-radius:0 6px 6px 0">'
        +'<div style="display:flex;justify-content:space-between;gap:6px;margin-bottom:4px"><div><span style="color:#FF9900;font-size:13px">'+stars+'</span> <span style="color:#FF9900;font-size:11px;font-weight:700">'+(r.rating>0?r.rating.toFixed(1):'?')+'</span> '+lbl+'</div><span style="font-size:10px;color:#475569">'+r.date+'</span></div>'
        +(r.title?'<div style="font-weight:600;color:#CBD5E1;margin-bottom:3px;font-size:12px">'+r.title+'</div>':'')
        +'<div style="margin-bottom:4px">'+vb+'</div>'
        +'<div style="color:#94A3B8;font-size:12px;line-height:1.6">'+r.body.replace(/\n/g,'<br>').substring(0,400)+(r.body.length>400?'…':'')+'</div></div>';
    }).join('');
    var ep=document.getElementById('_bhl_amz_panel'); if(ep) ep.remove();
    var panel=document.createElement('div'); panel.id='_bhl_amz_panel';
    panel.style.cssText='position:fixed;top:16px;right:16px;z-index:2147483647;width:480px;max-height:90vh;overflow-y:auto;background:#0F172A;color:#E2E8F0;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.7);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:13px;line-height:1.5';
    var ptEl=document.querySelector('#productTitle,h1.a-size-large,[data-hook="product-link"]');
    var productTitle=ptEl?ptEl.textContent.trim():'ASIN: '+asin;
    panel.innerHTML=
      '<div style="background:#064E3B;padding:13px 16px;border-radius:12px 12px 0 0;text-align:center;font-size:13px;font-weight:700;color:#22C55E">✅ 全件取得完了　合計 '+total+' 件</div>'
      +'<div style="background:#1E3A5F;padding:14px 16px;display:flex;align-items:center;gap:10px">'
      +'<div style="background:#FF9900;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0">★</div>'
      +'<div style="flex:1;min-width:0"><div style="font-weight:700;font-size:14px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+productTitle+'</div>'
      +'<div style="font-size:11px;color:#94A3B8;margin-top:2px">ASIN: '+asin+'</div></div>'
      +'<button id="_bhl_close" style="background:none;border:none;color:#94A3B8;font-size:22px;cursor:pointer;flex-shrink:0">×</button></div>'
      +'<div style="display:flex;align-items:center;justify-content:center;gap:20px;padding:12px 16px;background:#162032;border-bottom:1px solid #1E3A5F">'
      +'<div style="text-align:center"><div style="font-size:28px;font-weight:700;color:#FF9900">'+aAll+'</div><div style="font-size:11px;color:#64748B">★ 平均</div></div>'
      +'<div style="width:1px;height:40px;background:#1E3A5F"></div>'
      +'<div style="text-align:center"><div style="font-size:28px;font-weight:700;color:#fff">'+total+'</div><div style="font-size:11px;color:#64748B">件取得</div></div>'
      +'<div style="width:1px;height:40px;background:#1E3A5F"></div>'
      +'<div style="text-align:center"><div style="font-size:20px;font-weight:700;color:#C4B5FD">'+vC+'<span style="font-size:12px;color:#64748B"> Vine</span></div><div style="font-size:11px;color:#64748B">'+vP+'%</div></div>'
      +'<div style="text-align:center"><div style="font-size:20px;font-weight:700;color:#67E8F9">'+nvC+'<span style="font-size:12px;color:#64748B"> 非Vine</span></div><div style="font-size:11px;color:#64748B">'+(100-vP)+'%</div></div></div>'
      +monthChart(reviews)
      +'<div style="padding:14px 16px;background:#162032;border-bottom:1px solid #1E3A5F">'
      +distChart(reviews,'■ 全体','#FF9900')+distChart(vRv,'■ Vine（購入バッジなし）','#C4B5FD')+distChart(nvRv,'■ 非Vine（Amazonで購入）','#67E8F9')
      +'</div>'
      +'<div style="padding:10px 16px;border-bottom:1px solid #1E3A5F"><div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center">'
      +'<button data-f="all" style="padding:5px 10px;border-radius:20px;border:1px solid #FF9900;background:#FF9900;color:#000;font-size:11px;font-weight:700;cursor:pointer">全て('+total+')</button>'
      +'<button data-f="good" style="padding:5px 10px;border-radius:20px;border:1px solid #22C55E;background:transparent;color:#22C55E;font-size:11px;cursor:pointer">★5・4('+goodC+')</button>'
      +'<button data-f="mid" style="padding:5px 10px;border-radius:20px;border:1px solid #94A3B8;background:transparent;color:#94A3B8;font-size:11px;cursor:pointer">★3('+midC+')</button>'
      +'<button data-f="bad" style="padding:5px 10px;border-radius:20px;border:1px solid #FF4B4B;background:transparent;color:#FF4B4B;font-size:11px;cursor:pointer">★2・1('+badC+')</button>'
      +'<button data-f="vine" style="padding:5px 10px;border-radius:20px;border:1px solid #8B5CF6;background:transparent;color:#C4B5FD;font-size:11px;cursor:pointer">Vine('+vC+')</button>'
      +'<button data-f="novine" style="padding:5px 10px;border-radius:20px;border:1px solid #06B6D4;background:transparent;color:#67E8F9;font-size:11px;cursor:pointer">非Vine('+nvC+')</button>'
      +'<button id="_bhl_csv" style="margin-left:auto;padding:5px 10px;border-radius:20px;border:1px solid #3B82F6;background:transparent;color:#3B82F6;font-size:11px;cursor:pointer">📥 CSV</button>'
      +'</div></div>'
      +'<div id="_bhl_amz_list" style="padding:8px 16px 16px">'+listHTML+'</div>'
      +'<div style="padding:10px 16px;background:#162032;border-top:1px solid #1E3A5F;border-radius:0 0 12px 12px;text-align:center;font-size:11px;color:#475569">'
      +(total>500?'最新500件を表示（全'+total+'件はCSVで取得可）':'全'+total+'件を表示中')+'</div>';
    document.body.appendChild(panel);
    window._bhlAmzAllReviews = reviews;

    // イベントバインド（CSPでonclick属性が効かない環境対応）
    document.getElementById('_bhl_close').onclick=function(){ panel.remove(); };
    document.getElementById('_bhl_csv').onclick=function(){ doCSV(); };
    panel.querySelectorAll('button[data-f]').forEach(function(b){
      b.onclick=function(){ doFilter(b.getAttribute('data-f'), b); };
    });
  }

  function doCSV(){
    var all=window._bhlAmzAllReviews||[];
    var visIdx=[];
    document.querySelectorAll('#_bhl_amz_list [data-idx]').forEach(function(el){ if(el.style.display!=='none') visIdx.push(parseInt(el.getAttribute('data-idx'))); });
    var anyFiltered = document.querySelectorAll('#_bhl_amz_list [data-idx]').length !== visIdx.length;
    var target = anyFiltered ? visIdx.map(function(i){return all[i];}).filter(Boolean) : all;
    if(!target.length){alert('レビューがありません');return;}
    var rows=[['評価','Vine','タイトル','本文','レビュー日']];
    target.forEach(function(r){rows.push([r.rating,r.vine?'Vine':'非Vine',r.title,r.body.replace(/\n/g,' ').replace(/\r/g,''),r.date]);});
    var csv=rows.map(function(r){return r.map(function(c){return'"'+String(c||'').replace(/"/g,'""')+'"';}).join(',');}).join('\n');
    var a2=document.createElement('a');a2.href='data:text/csv;charset=utf-8,\uFEFF'+encodeURIComponent(csv);a2.download='amazon_reviews_'+asin+'_'+target.length+'件.csv';a2.click();
  }
  function doFilter(f,btn){
    document.querySelectorAll('#_bhl_amz_panel button[data-f]').forEach(function(b){var cs={all:'#FF9900',good:'#22C55E',mid:'#94A3B8',bad:'#FF4B4B',vine:'#8B5CF6',novine:'#06B6D4'};var c=cs[b.getAttribute('data-f')]||'#94A3B8';b.style.background='transparent';b.style.color=c;b.style.borderColor=c;});
    var cs={all:'#FF9900',good:'#22C55E',mid:'#94A3B8',bad:'#FF4B4B',vine:'#8B5CF6',novine:'#06B6D4'};
    btn.style.background=cs[f]||'#94A3B8';btn.style.color=f==='all'?'#000':'#fff';
    document.querySelectorAll('#_bhl_amz_list [data-idx]').forEach(function(el){var rs=Math.round(parseFloat(el.getAttribute('data-r')||'0'));var v=el.getAttribute('data-vine')==='1';el.style.display=(f==='all'?true:f==='good'?rs>=4:f==='mid'?rs===3:f==='bad'?(rs<=2&&rs>0):f==='vine'?v:f==='novine'?!v:false)?'':'none';});
  }
  function playDone(){try{var ctx=new(window.AudioContext||window.webkitAudioContext)();[[523,0],[659,.15],[784,.3],[1047,.5]].forEach(function(n){var o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=n[0];o.type='sine';g.gain.setValueAtTime(.3,ctx.currentTime+n[1]);g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+n[1]+.4);o.start(ctx.currentTime+n[1]);o.stop(ctx.currentTime+n[1]+.5);});}catch(e){}}

  // ══ 起動判定 ══
  // 収集中（state存在）なら自動継続。開始フラグ（start）があれば新規開始。
  (async function(){
    var data = await getLocal([STATE_KEY, START_KEY]);
    if(data[STATE_KEY]){
      // 収集中 → ページ遷移で戻ってきた。続行
      updateProgress('読み込み完了、続きを収集中…');
      await delay(1200);
      runStep();
    } else if(data[START_KEY]){
      // 開始フラグあり → 新規収集スタート
      await removeLocal([START_KEY]);
      var fresh = { reviews:[], seenKeys:{}, filterIdx:0, clicksInFilter:0 };
      await setLocal({[STATE_KEY]: fresh});
      updateProgress('ハイブリッド収集を開始（全体→★5→★4→★3→★2→★1）…');
      await delay(900);
      runStep();
    }
    // どちらもなければ何もしない（普通の閲覧）
  })();

})();
