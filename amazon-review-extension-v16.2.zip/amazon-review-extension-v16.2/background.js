// 拡張機能アイコンクリック時: 収集開始フラグを立てて、レビューページへ誘導
chrome.action.onClicked.addListener(async function(tab){
  if(!tab.url || tab.url.indexOf('amazon.co.jp') < 0){
    return;
  }
  // ASINを抽出
  var asin = null;
  var m = tab.url.match(/\/(?:dp|gp\/product|product-reviews)\/([A-Z0-9]{10})/i);
  if(m) asin = m[1].toUpperCase();
  if(!asin){
    chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:function(){ alert('Amazonの商品ページまたはレビューページで実行してください'); }
    });
    return;
  }
  // 収集開始フラグをstorageに保存（content.jsが検知して動く）
  var startState = {};
  startState['start_'+asin] = true;
  await chrome.storage.local.set(startState);
  // 全体レビューの新着順ページへ遷移（ここでcontent.jsが起動する）
  var target = 'https://www.amazon.co.jp/product-reviews/'+asin+'/?sortBy=recent&pageNumber=1';
  chrome.tabs.update(tab.id, {url: target});
});
